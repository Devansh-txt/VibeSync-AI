from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv
import os
import traceback
import urllib.parse
import random

base_dir = os.path.abspath(os.path.dirname(__file__))
load_dotenv(os.path.join(base_dir, '.env'))

from services.gemini_service import GeminiService
from services.spotify_service import SpotifyService

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'default-safe-key-vibe-102')

music_service = None
spotify_service = None
gemini_init_error = None

try:
    music_service = GeminiService()
except Exception as error:
    gemini_init_error = traceback.format_exc()

try:
    spotify_service = SpotifyService()
except Exception:
    pass

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/recommend', methods=['POST'])
def recommend():
    data = request.get_json() or {}
    user_mood = data.get('mood', '').strip()

    if not user_mood:
        return jsonify({"error": "Vibe query cannot be left blank."}), 400

    # 1. Check for explicit language requests in the user's prompt text
    prompt_lower = user_mood.lower()
    is_hindi_requested = any(w in prompt_lower for w in ['hindi', 'ghazal', 'bollywood', 'indian', 'sufi', 'urdu', 'punjabi'])
    is_english_requested = any(w in prompt_lower for w in ['english', 'western', 'pop', 'rock', 'hollywood'])

    # 2. Call Gemini for analysis, but handle failures safely without breaking the music genre
    detected_genre = 'pop'
    detected_emotion = user_mood.capitalize()
    detected_desc = "Custom curated playlist tailored to your mood description."
    
    val_valence, val_energy, val_danceability, val_tempo = 0.5, 0.5, 0.5, 90.0

    if music_service:
        try:
            mood_analysis = music_service.generate_playlist(user_mood)
            if mood_analysis and isinstance(mood_analysis, dict):
                detected_genre = mood_analysis.get('genre') or mood_analysis.get('target_genre') or detected_genre
                detected_emotion = mood_analysis.get('emotion') or mood_analysis.get('mood') or detected_emotion
                detected_desc = mood_analysis.get('description') or mood_analysis.get('explanation') or detected_desc
                val_valence = mood_analysis.get('valence', 0.5)
                val_energy = mood_analysis.get('energy', 0.5)
                val_danceability = mood_analysis.get('danceability', 0.5)
                val_tempo = mood_analysis.get('tempo', 90.0)
        except Exception as e:
            print(f"--- Gemini tracking error handled: {e} ---")

    # 3. Pull recommendations from Spotify based on strict rules
    raw_tracks = []
    if spotify_service:
        # Scenario A: Mixed Hindi & English Blend
        if is_hindi_requested and is_english_requested:
            indian_genre = 'bollywood' if 'bollywood' in prompt_lower else 'indian'
            english_genre = 'pop' if detected_genre in ['indian', 'bollywood'] else detected_genre
            
            # Lower mood parameters specifically for ghazals if requested
            if 'ghazal' in prompt_lower:
                val_energy, val_valence = 0.3, 0.4

            indian_res = spotify_service.get_recommendations(indian_genre, val_valence, val_energy, val_danceability, val_tempo) or []
            english_res = spotify_service.get_recommendations(english_genre, val_valence, val_energy, val_danceability, val_tempo) or []
            
            # Interleave lists to guarantee both languages show up
            for i in range(max(len(indian_res), len(english_res))):
                if i < len(indian_res): raw_tracks.append(indian_res[i])
                if i < len(english_res): raw_tracks.append(english_res[i])
                
        # Scenario B: Pure Hindi / Ghazal request
        elif is_hindi_requested:
            target_seed = 'bollywood' if 'bollywood' in prompt_lower else 'indian'
            if 'ghazal' in prompt_lower:
                val_energy, val_valence = 0.25, 0.35  # True soulful acoustic features
            raw_tracks = spotify_service.get_recommendations(target_seed, val_valence, val_energy, val_danceability, val_tempo) or []
            detected_genre = "Bollywood / Ghazal" if 'ghazal' in prompt_lower else "Hindi Music"

        # Scenario C: Default English / Western request
        else:
            raw_tracks = spotify_service.get_recommendations(detected_genre, val_valence, val_energy, val_danceability, val_tempo) or []

    # 4. Map the track items and generate real working URLs
    normalized_tracks = []
    for track in raw_tracks:
        t_name = track.get('name') or track.get('title') or 'Acoustic Vibe'
        
        t_artist = track.get('artist')
        if not t_artist and track.get('artists') and len(track['artists']) > 0:
            # FIX: Swapped out typo bracket ']' for proper function syntax closure ')'
            t_artist = track['artists'][0].get('name') if isinstance(track['artists'][0], dict) else 'Various Artists'
        if not t_artist:
            t_artist = 'Vibe Collective'

        t_album = track.get('album_name') or (track.get('album', {}).get('name') if isinstance(track.get('album'), dict) else 'Soundscape')

        search_query = f"{t_name} {t_artist}"
        spotify_search_url = f"https://open.spotify.com/search/{urllib.parse.quote(search_query)}"

        # Visual cleanup for the language badges
        track_display_genre = detected_genre.capitalize()
        artist_lower = t_artist.lower()
        if any(w in artist_lower or w in t_name.lower() for w in ['arijit', 'kishore', 'jagjit', 'lata', 'rafi', 'shreya', 'nusrat', 'anuv', 'prateek', 'kumar', 'alká']):
            track_display_genre = "Hindi / Indian"

        normalized_tracks.append({
            "title": t_name,
            "name": t_name,
            "artist": t_artist,
            "album": t_album,
            "genre": track_display_genre,
            "description": f"Matches your requested {detected_emotion} layout perfectly.",
            "url": spotify_search_url
        })

    return jsonify({
        "vibe": detected_emotion,
        "description": detected_desc,
        "tracks": normalized_tracks[:10]  # Show top 10 unique items
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)