document.addEventListener("DOMContentLoaded", () => {
    // Initialize Theme State Mechanics
    initThemeControl();

    // Initialize Interactive Particle System Background Context Canvas
    initParticleEngine();

    // Initialize View Controller Core Endpoints
    if (document.getElementById("mood-generator-form")) {
        initEngineWorkspace();
    }

    if (document.getElementById("favs-grid-container")) {
        initFavoritesEngine();
    }
});

/* ==========================================
   THEME SWITCH ROUTINES
   ========================================== */
function initThemeControl() {
    const toggleBtn = document.getElementById("theme-toggle");
    if (!toggleBtn) return;

    const savedTheme = localStorage.getItem("aura-theme") || "dark";
    document.documentElement.setAttribute("data-theme", savedTheme);

    toggleBtn.addEventListener("click", () => {
        const currentTheme = document.documentElement.getAttribute("data-theme");
        const nextTheme = currentTheme === "dark" ? "light" : "dark";
        document.documentElement.setAttribute("data-theme", nextTheme);
        localStorage.setItem("aura-theme", nextTheme);
    });
}

/* ==========================================
   FLUID BACKGROUND PARTICLE MATRIX
   ========================================== */
function initParticleEngine() {
    const canvas = document.getElementById("particle-canvas");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");

    let particles = [];
    const particleCount = 45;

    function resizeCanvas() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    resizeCanvas();
    window.addEventListener("resize", resizeCanvas);

    class Particle {
        constructor() {
            this.x = Math.random() * canvas.width;
            this.y = Math.random() * canvas.height;
            this.radius = Math.random() * 2.5 + 0.5;
            this.vx = (Math.random() - 0.5) * 0.3;
            this.vy = (Math.random() - 0.5) * 0.3;
            this.alpha = Math.random() * 0.5 + 0.2;
        }
        update() {
            this.x += this.vx;
            this.y += this.vy;
            if (this.x < 0 || this.x > canvas.width) this.vx *= -1;
            if (this.y < 0 || this.y > canvas.height) this.vy *= -1;
        }
        draw() {
            ctx.beginPath();
            const isDark = document.documentElement.getAttribute("data-theme") === "dark";
            ctx.fillStyle = isDark ? `rgba(139, 92, 246, ${this.alpha})` : `rgba(109, 40, 217, ${this.alpha * 0.4})`;
            ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
            ctx.fill();
        }
    }

    for (let i = 0; i < particleCount; i++) {
        particles.push(new Particle());
    }

    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        particles.forEach(p => {
            p.update();
            p.draw();
        });
        requestAnimationFrame(animate);
    }
    animate();
}

/* ==========================================
   CORE WORKSPACE OPERATIONS (RECOMMENDATIONS & CHAT)
   ========================================== */
function initEngineWorkspace() {
    const moodForm = document.getElementById("mood-generator-form");
    const tracksGrid = document.getElementById("tracks-grid-target");
    const spinner = document.getElementById("tracks-loading-spinner");
    const analysisPanel = document.getElementById("analysis-result-panel");
    const manualSearchInput = document.getElementById("manual-track-search");
    
    // Emoji handling setup
    const emojiItems = document.querySelectorAll(".emoji-item");
    emojiItems.forEach(item => {
        item.addEventListener("click", () => {
            emojiItems.forEach(i => i.classList.remove("active"));
            item.classList.add("active");
        });
    });

    // Mood Generation Analysis Request Pipeline Handler
    moodForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        
        const moodText = document.getElementById("mood-text").value;
        const energyLevel = document.getElementById("energy-select").value;
        const activityInput = document.getElementById("activity-input").value;
        
        spinner.classList.remove("hidden");
        tracksGrid.innerHTML = "";
        
        try {
            const response = await fetch("/recommend", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ mood: moodText, energy: energyLevel, activity: activityInput })
            });
            
            const data = await response.json();
            spinner.classList.add("hidden");
            
            if (response.ok) {
                renderVectorBreakdown(data.analysis);
                renderTrackGrid(data.tracks);
            } else {
                tracksGrid.innerHTML = `<div class='error-msg'>${data.error || "Execution fault encountered"}</div>`;
            }
        } catch (err) {
            spinner.classList.add("hidden");
            tracksGrid.innerHTML = "<div class='error-msg'>Failed to communicate with runtime microservice core.</div>";
        }
    });

    // Real-Time Manual Search Interaction Handlers
    let debounceTimer;
    manualSearchInput.addEventListener("input", (e) => {
        clearTimeout(debounceTimer);
        const query = e.target.value.trim();
        if (!query) return;

        debounceTimer = setTimeout(async () => {
            spinner.classList.remove("hidden");
            try {
                const res = await fetch(`/search?q=${encodeURIComponent(query)}`);
                const data = await res.json();
                spinner.classList.add("hidden");
                renderTrackGrid(data.tracks);
            } catch (err) {
                spinner.classList.add("hidden");
            }
        }, 400);
    });

    function renderVectorBreakdown(analysis) {
        analysisPanel.classList.remove("hidden");
        document.getElementById("confidence-score-badge").innerText = `Match Score: ${Math.round(analysis.confidence * 100)}%`;
        
        // Dynamic Bar Transitions
        document.getElementById("fill-valence").style.width = `${analysis.valence * 100}%`;
        document.getElementById("fill-energy").style.width = `${analysis.energy * 100}%`;
        document.getElementById("fill-dance").style.width = `${analysis.danceability * 100}%`;
        
        // Typing Animation Effect
        const expText = document.getElementById("analysis-explanation-text");
        expText.innerText = "";
        let i = 0;
        function type() {
            if (i < analysis.explanation.length) {
                expText.innerHTML += analysis.explanation.charAt(i);
                i++;
                setTimeout(type, 15);
            }
        }
        type();
    }

    function renderTrackGrid(tracks) {
        if (!tracks || tracks.length === 0) {
            tracksGrid.innerHTML = "<div class='quiet-notice'>No tracks matched your vector targets. Try tweaking your text input.</div>";
            return;
        }

        // Fetch user favorites list asynchronously to display filled states accurately
        fetch("/favorites")
            .then(res => res.json())
            .then(favData => {
                const favIds = new Set((favData.favorites || []).map(f => f.track_id));
                tracksGrid.innerHTML = "";
                
                tracks.forEach(track => {
                    const isFav = favIds.has(track.id);
                    const card = document.createElement("div");
                    card.className = "track-card";
                    card.innerHTML = `
                        <div class="card-art-frame">
                            <img src="${track.album_art || 'https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?w=300'}" alt="Artwork">
                        </div>
                        <div class="track-title-txt">${track.name}</div>
                        <div class="track-artist-txt">${track.artist}</div>
                        
                        ${track.preview_url ? `
                            <audio class="audio-preview-player" controls src="${track.preview_url}"></audio>
                        ` : '<div class="track-artist-txt" style="font-style:italic; margin-top:10px;">Preview unavailable</div>'}
                        
                        <div class="card-action-triggers">
                            <button class="btn-fav-toggle ${isFav ? 'favorited' : ''}" 
                                    data-id="${track.id}" 
                                    data-name="${escapeHtml(track.name)}" 
                                    data-artist="${escapeHtml(track.artist)}" 
                                    data-art="${track.album_art}" 
                                    data-preview="${track.preview_url || ''}">
                                ❤️
                            </button>
                        </div>
                    `;
                    tracksGrid.appendChild(card);
                });

                attachCardActionListeners();
            });
    }

    function attachCardActionListeners() {
        document.querySelectorAll(".btn-fav-toggle").forEach(btn => {
            btn.addEventListener("click", async (e) => {
                e.preventDefault();
                const payload = {
                    track_id: btn.getAttribute("data-id"),
                    track_name: btn.getAttribute("data-name"),
                    artist_name: btn.getAttribute("data-artist"),
                    album_art: btn.getAttribute("data-art"),
                    preview_url: btn.getAttribute("data-preview")
                };

                try {
                    const res = await fetch("/favorites/toggle", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify(payload)
                    });
                    const resData = await res.json();
                    if (resData.status === "added") {
                        btn.classList.add("favorited");
                    } else if (resData.status === "removed") {
                        btn.classList.remove("favorited");
                    }
                } catch (err) {
                    console.error("Failed to commit modification to backend favorite nodes.", err);
                }
            });
        });
    }

    // AI Companion Chatbot Module Interactions
    const chatSendBtn = document.getElementById("chat-send-btn");
    const chatUserInput = document.getElementById("chat-user-input");
    const chatMessagesDisplay = document.getElementById("chat-messages");
    let chatHistoryTimeline = [];

    if (chatSendBtn && chatUserInput) {
        chatSendBtn.addEventListener("click", sendChatMessage);
        chatUserInput.addEventListener("keypress", (e) => { if (e.key === "Enter") sendChatMessage(); });
    }

    async function sendChatMessage() {
        const msg = chatUserInput.value.trim();
        if (!msg) return;

        // Append message node natively
        appendMsgUI("user", msg);
        chatUserInput.value = "";

        try {
            const response = await fetch("/chat", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ message: msg, history: chatHistoryTimeline })
            });
            const data = await response.json();
            if (response.ok) {
                appendMsgUI("system", data.response);
                chatHistoryTimeline.push({ role: "user", content: msg });
                chatHistoryTimeline.push({ role: "assistant", content: data.response });
            } else {
                appendMsgUI("system", "Error tracking contextual analytics mapping.");
            }
        } catch (err) {
            appendMsgUI("system", "Failed to resolve engine response streams.");
        }
    }

    function appendMsgUI(sender, text) {
        const row = document.createElement("div");
        row.className = `message ${sender}-message`;
        row.innerText = text;
        chatMessagesDisplay.appendChild(row);
        chatMessagesDisplay.scrollTop = chatMessagesDisplay.scrollHeight;
    }

    function escapeHtml(string) {
        return String(string).replace(/[&<>"']/g, function (s) {
            return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[s];
        });
    }
}

/* ==========================================
   DASHBOARD / FAVORITES MODULE MANAGEMENT
   ========================================== */
function initFavoritesEngine() {
    document.querySelectorAll(".btn-fav-toggle").forEach(btn => {
        btn.addEventListener("click", async () => {
            const trackId = btn.getAttribute("data-track-id");
            try {
                const res = await fetch("/favorites/toggle", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ track_id: trackId })
                });
                const data = await res.json();
                if (data.status === "removed") {
                    const targetCard = document.querySelector(`.track-card[data-id="${trackId}"]`);
                    if (targetCard) targetCard.remove();
                }
            } catch (err) {
                console.error("Database deletion sync failed", err);
            }
        });
    });
}