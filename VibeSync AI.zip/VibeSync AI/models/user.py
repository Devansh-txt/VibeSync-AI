import sqlite3
from database.db import get_db_connection
from werkzeug.security import generate_password_hash, check_password_hash
from database.db import get_db_connection
from werkzeug.security import generate_password_hash, check_password_hash

class UserModel:
    @staticmethod
    def create_user(username, email, password):
        hashed = generate_password_hash(password)
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(
                "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)",
                (username, email, hashed)
            )
            conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False
        finally:
            conn.close()

    @staticmethod
    def find_by_username(username):
        conn = get_db_connection()
        user = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
        conn.close()
        return user

    @staticmethod
    def find_by_id(user_id):
        conn = get_db_connection()
        user = conn.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        conn.close()
        return user

class HistoryModel:
    @staticmethod
    def add_log(user_id, mood_text, energy_level, detected_emotion, confidence_score, primary_genre):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO mood_history (user_id, mood_text, energy_level, detected_emotion, confidence_score, primary_genre)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (user_id, mood_text, energy_level, detected_emotion, confidence_score, primary_genre))
        conn.commit()
        conn.close()

    @staticmethod
    def get_user_history(user_id, limit=10):
        conn = get_db_connection()
        logs = conn.execute('''
            SELECT * FROM mood_history WHERE user_id = ? 
            ORDER BY created_at DESC LIMIT ?
        ''', (user_id, limit)).fetchall()
        conn.close()
        return [dict(log) for log in logs]

class FavoriteModel:
    @staticmethod
    def add_favorite(user_id, track_id, track_name, artist_name, album_art_url, preview_url):
        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute('''
                INSERT OR IGNORE INTO favorites (user_id, track_id, track_name, artist_name, album_art_url, preview_url)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (user_id, track_id, track_name, artist_name, album_art_url, preview_url))
            conn.commit()
            return True
        except Exception:
            return False
        finally:
            conn.close()

    @staticmethod
    def remove_favorite(user_id, track_id):
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM favorites WHERE user_id = ? AND track_id = ?", (user_id, track_id))
        conn.commit()
        conn.close()

    @staticmethod
    def get_user_favorites(user_id):
        conn = get_db_connection()
        favs = conn.execute("SELECT * FROM favorites WHERE user_id = ? ORDER BY created_at DESC", (user_id,)).fetchall()
        conn.close()
        return [dict(fav) for fav in favs]