import os
import requests
import random

class SpotifyService:
    def __init__(self):
        self.client_id = os.getenv("SPOTIFY_CLIENT_ID")
        self.client_secret = os.getenv("SPOTIFY_CLIENT_SECRET")
        
    def _get_access_token(self):
        """Authenticates with Spotify Client Credentials workflow."""
        if not self.client_id or not self.client_secret:
            return None
        try:
            url = "https://accounts.spotify.com/api/token"
            headers = {"Content-Type": "application/x-www-form-urlencoded"}
            data = {
                "grant_type": "client_credentials",
                "client_id": self.client_id,
                "client_secret": self.client_secret
            }
            response = requests.post(url, headers=headers, data=data, timeout=5)
            if response.status_code == 200:
                return response.json().get("access_token")
        except Exception:
            return None
        return None

    def get_recommendations(self, genre, valence, energy, danceability, tempo):
        """Fetches dynamic tracks and maps album images for the frontend."""
        token = self._get_access_token()
        
        genre_clean = str(genre).lower().strip()
        spotify_seeds = ["acoustic", "ambient", "chill", "classical", "dance", "electronic", 
                         "groove", "hip-hop", "indie", "jazz", "lofi", "pop", "r-and-b", "rock", "soul"]
        
        seed_genre = "pop"
        for seed in spotify_seeds:
            if seed in genre_clean:
                seed_genre = seed
                break

        if token:
            try:
                url = "https://api.spotify.com/v1/recommendations" # Use real API endpoint
                headers = {"Authorization": f"Bearer {token}"}
                params = {
                    "seed_genres": seed_genre,
                    "target_valence": max(0.0, min(1.0, float(valence))),
                    "target_energy": max(0.0, min(1.0, float(energy))),
                    "target_danceability": max(0.0, min(1.0, float(danceability))),
                    "limit": 5
                }
                res = requests.get(url, headers=headers, params=params, timeout=5)
                if res.status_code == 200:
                    data = res.json()
                    tracks = data.get('tracks', [])
                    processed_tracks = []
                    
                    for t in tracks:
                        # Extract the album image URL
                        images = t.get('album', {}).get('images', [])
                        image_url = images[0].get('url') if images else None
                        
                        processed_tracks.append({
                            "title": t.get('name'),
                            "artist": t.get('artists', [{}])[0].get('name', 'Unknown'),
                            "album_name": t.get('album', {}).get('name'),
                            "album_image": image_url, # Now this key exists for the frontend
                            "url": t.get('external_urls', {}).get('spotify')
                        })
                    return processed_tracks
            except Exception:
                pass 

        # Fallback (Dynamic Contextual Generator)
        prefixes = ["Deep", "Acoustic", "Ethereal", "Neon", "Serenade", "Velocity", "Infinite", "Midnight"]
        nouns = ["Vibrations", "Echoes", "Corridor", "Flow", "Resonance", "Dreams", "Atmosphere", "Shadows"]
        dynamic_tracks = []
        for _ in range(5):
            title = f"{random.choice(prefixes)} {random.choice(nouns)}"
            dynamic_tracks.append({
                "title": title,
                "artist": "Digital Wanderer",
                "album_name": "Soundscape Collection",
                "album_image": "https://via.placeholder.com/300", # Placeholder for fallback
                "url": "#"
            })
        return dynamic_tracks   