import os
import json
from google import genai
from google.genai import types
from pydantic import BaseModel, Field

# Define strict response structure required by the Spotify recommend route
class MoodAnalysisSchema(BaseModel):
    genre: str = Field(description="A single lowercase music genre keyword appropriate for Spotify filtering (e.g., 'pop', 'rock', 'classical', 'jazz', 'lofi', 'dance')")
    valence: float = Field(description="Value from 0.0 to 1.0 describing the musical positiveness conveyed by the track.")
    energy: float = Field(description="Value from 0.0 to 1.0 representing a perceptual measure of intensity and activity.")
    danceability: float = Field(description="Value from 0.0 to 1.0 describing how suitable a track is for dancing.")
    tempo: float = Field(description="The overall estimated tempo of a track in beats per minute (BPM) as a raw float.")
    emotion: str = Field(description="A clear naming descriptor of the primary emotional state found in the prompt.")
    confidence: float = Field(description="Floating point value between 0.0 and 1.0 indicating AI analysis certainty.")

class GeminiService:
    def __init__(self):
        # 1. Explicitly grab the key and pass it to the constructor to stop the initialization error
        api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
        if not api_key:
            raise ValueError("GEMINI_API_KEY environment variable is entirely missing or unreadable.")
            
        self.client = genai.Client(api_key=api_key)
        self.model_name = "gemini-2.5-flash"

    def generate_playlist(self, mood_text: str) -> dict:
        """
        Added wrapper method to map what app.py expects 
        to our actual structured analyze_mood engine.
        """
        return self.analyze_mood(
            mood_text=mood_text, 
            energy_level="balanced", 
            activity="chilling"
        )

    def analyze_mood(self, mood_text: str, energy_level: str, activity: str) -> dict:
        """Analyzes textual user indicators and enforces a strict structured JSON profile matching Spotify parameters."""
        prompt = f"""
        Analyze the following emotional profile and output exact metric settings for music alignment:
        - User statement: "{mood_text}"
        - Selected user target energy benchmark: "{energy_level}"
        - Current physical/mental activity context: "{activity}"
        """
        
        try:
            response = self.client.models.generate_content(
                model=self.model_name,
                contents=prompt,
                config=types.GenerateContentConfig(
                    response_mime_type="application/json",
                    response_schema=MoodAnalysisSchema,
                    temperature=0.4
                )
            )
            # Parses the automatically validated JSON output string safely into a clean dictionary
            return json.loads(response.text)
            
        except Exception as e:
            print(f"Gemini Service Failure during analysis: {str(e)}")
            # Fallback values to prevent application crashes
            return {
                "genre": "pop",
                "valence": 0.5,
                "energy": 0.5,
                "danceability": 0.5,
                "tempo": 120.0,
                "emotion": "Neutral / Undetermined",
                "confidence": 0.0
            }

    def chatbot_respond(self, formatted_history: list) -> str:
        """Processes continuous conversational arrays while mapping formats to Google specifications."""
        gemini_contents = []
        
        for message in formatted_history:
            role = "model" if message['role'] in ['assistant', 'system'] else "user"
            
            gemini_contents.append(
                types.Content(
                    role=role,
                    parts=[types.Part.from_text(text=message['content'])]
                )
            )
            
        try:
            response = self.client.models.generate_content(
                model=self.model_name,
                contents=gemini_contents
            )
            return response.text if response.text else "I am processing that alignment but could not generate textual content."
        except Exception as e:
            return f"Gemini Chat Module encountered an exception routine: {str(e)}"