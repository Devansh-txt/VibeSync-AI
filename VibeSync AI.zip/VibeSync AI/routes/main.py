from flask import Blueprint, render_template, request, jsonify, session, redirect, url_for
from services.gemini_service import GeminiService
from services.spotify_service import SpotifyService
from models.user import HistoryModel, FavoriteModel

main_bp = Blueprint('main', __name__)

# Initialize the new Gemini service core engine
gemini_service = GeminiService()
spotify_service = SpotifyService()

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function

@main_bp.route('/')
@login_required
def index():
    return render_template('index.html', username=session.get('username'))

@main_bp.route('/recommend', methods=['POST'])
@login_required
def recommend():
    data = request.get_json() or {}
    mood_text = data.get('mood', '').strip()
    energy_level = data.get('energy', 'medium')
    activity = data.get('activity', '').strip()
    
    if not mood_text:
        return jsonify({"error": "Mood content field must not be empty"}), 400
        
    # Process inputs through the Google Gemini analysis engine
    analysis = gemini_service.analyze_mood(mood_text, energy_level, activity)
    
    # Retrieve track entries matching calculated metrics from Gemini
    tracks = spotify_service.get_recommendations(
        genre=analysis['genre'],
        valence=analysis['valence'],
        energy=analysis['energy'],
        danceability=analysis['danceability'],
        tempo=analysis['tempo']
    )
    
    # Commit execution analytics to history log
    HistoryModel.add_log(
        user_id=session['user_id'],
        mood_text=mood_text,
        energy_level=energy_level,
        detected_emotion=analysis['emotion'],
        confidence_score=analysis['confidence'],
        primary_genre=analysis['genre']
    )
    
    return jsonify({
        "analysis": analysis,
        "tracks": tracks
    })

@main_bp.route('/search', methods=['GET'])
@login_required
def search():
    query = request.args.get('q', '').strip()
    if not query:
        return jsonify({"tracks": []})
    tracks = spotify_service.search_tracks(query)
    return jsonify({"tracks": tracks})

@main_bp.route('/favorites', methods=['GET'])
@login_required
def get_favorites():
    favs = FavoriteModel.get_user_favorites(session['user_id'])
    return jsonify({"favorites": favs})

@main_bp.route('/favorites/toggle', methods=['POST'])
@login_required
def toggle_favorite():
    data = request.get_json() or {}
    track_id = data.get('track_id')
    
    if not track_id:
        return jsonify({"error": "Missing tracking identification sequence"}), 400
        
    current_favs = FavoriteModel.get_user_favorites(session['user_id'])
    is_favorited = any(f['track_id'] == track_id for f in current_favs)
    
    if is_favorited:
        FavoriteModel.remove_favorite(session['user_id'], track_id)
        return jsonify({"status": "removed", "track_id": track_id})
    else:
        FavoriteModel.add_favorite(
            user_id=session['user_id'],
            track_id=track_id,
            track_name=data.get('track_name'),
            artist_name=data.get('artist_name'),
            album_art_url=data.get('album_art'),
            preview_url=data.get('preview_url')
        )
        return jsonify({"status": "added", "track_id": track_id})

@main_bp.route('/dashboard', methods=['GET'])
@login_required
def dashboard():
    user_id = session['user_id']
    history = HistoryModel.get_user_history(user_id, limit=8)
    favorites = FavoriteModel.get_user_favorites(user_id)
    
    # Metric Processing
    total_scans = len(history)
    genre_counts = {}
    for entry in history:
        g = entry['primary_genre']
        genre_counts[g] = genre_counts.get(g, 0) + 1
        
    favorite_genre = max(genre_counts, key=genre_counts.get) if genre_counts else "None"
    
    return render_template(
        'dashboard.html', 
        history=history, 
        favorites=favorites,
        stats={"total_scans": total_scans, "favorite_genre": favorite_genre, "total_favorites": len(favorites)}
    )

@main_bp.route('/chat', methods=['POST'])
@login_required
def chat():
    data = request.get_json() or {}
    user_message = data.get('message', '').strip()
    history_payload = data.get('history', [])
    
    if not user_message:
        return jsonify({"error": "Message is required"}), 400
        
    # Format message timeline history for state context tracking
    formatted_history = []
    for msg in history_payload:
        formatted_history.append({"role": msg['role'], "content": msg['content']})
        
    formatted_history.append({"role": "user", "content": user_message})
    
    # Query Gemini Chat engine with context payload
    ai_response = gemini_service.chatbot_respond(formatted_history)
    
    return jsonify({"response": ai_response})